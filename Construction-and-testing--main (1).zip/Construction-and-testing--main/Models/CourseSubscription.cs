using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

public class CourseSubscription
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; } // Make it nullable

    [BsonElement("studentId")]
    public required string StudentId { get; set; }

    [BsonElement("courseId")]
    public required string CourseId { get; set; }

    [BsonElement("dateSubscribed")]
    public DateTime DateSubscribed { get; set; } = DateTime.UtcNow; // Default value
}
