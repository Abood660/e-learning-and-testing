using MongoDB.Bson.Serialization.Attributes;
using MongoExample.Models;

public class Student : User
{
    [BsonElement("isSubscribed")]
    public bool IsSubscribed { get; set; } = false;

    [BsonElement("progress")]
    public double Progress { get; set; } = 0.0;
}
