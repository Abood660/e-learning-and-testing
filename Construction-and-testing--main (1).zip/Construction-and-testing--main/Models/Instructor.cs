using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoExample.Models;
using System.Collections.Generic;

public class Instructor : User
{
    [BsonElement("coursesCreated")]
    public List<ObjectId> CoursesCreated { get; set; } = new List<ObjectId>(); // List of courses created by the instructor
}
