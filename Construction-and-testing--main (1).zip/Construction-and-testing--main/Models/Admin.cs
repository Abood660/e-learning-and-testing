namespace MongoExample.Models
{
    public class Admin : User
    {
        public string AdminLevel { get; set; } = "1";

    }
}