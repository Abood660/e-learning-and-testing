using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

public class Lesson
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string Id { get; set; } = ObjectId.GenerateNewId().ToString();

    [BsonElement("title")]
    [BsonRequired]
    public string Title { get; set; } = "";

    [BsonElement("url")]
    [BsonRequired]
    public string Url { get; set; } = "";

    [BsonElement("courseId")]
    [BsonRequired]
    public string CourseId { get; set; } = "";

    [BsonElement("dateCreated")]
    [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
    public DateTime DateCreated { get; set; } = DateTime.UtcNow;
}
