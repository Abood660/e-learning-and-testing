public class SubscribeCourseDto
{
    public required string CourseId { get; set; }
}
