using System.ComponentModel.DataAnnotations;

public class UserRegistrationDto
{
    public required string Name { get; set; }
    [Required]
    [EmailAddress]
    public required string Email { get; set; }
    public required string Password { get; set; }
    public required string Role { get; set; }

    public void ValidateRole()
    {
        if (!new[] { "Student", "Instructor" }.Contains(Role, StringComparer.OrdinalIgnoreCase))
        {
            throw new ArgumentException("Role must be either 'Student' or 'Instructor'.");
        }

    }
}
