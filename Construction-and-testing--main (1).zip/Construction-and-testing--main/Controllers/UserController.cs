// UserController.cs

using Microsoft.AspNetCore.Mvc;
using MongoExample.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly UserRepository _userRepository;
    private readonly IConfiguration _configuration;

    public UserController(UserRepository userRepository, IConfiguration configuration)
    {
        _userRepository = userRepository;
        _configuration = configuration;
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register(UserRegistrationDto userDto)
    {
        userDto.ValidateRole(); // Ensure role is valid.

        var existingUser = await _userRepository.GetUserByEmailAsync(userDto.Email);
        if (existingUser != null)
        {
            return Conflict("User with this email already exists.");
        }

        User user;

        if (userDto.Role.ToLower() == "student")
        {
            user = new Student
            {
                Name = userDto.Name,
                Email = userDto.Email,
                Password = BCrypt.Net.BCrypt.HashPassword(userDto.Password),
                Role = userDto.Role
            };
        }
        else if (userDto.Role.ToLower() == "instructor")
        {
            user = new Instructor
            {
                Name = userDto.Name,
                Email = userDto.Email,
                Password = BCrypt.Net.BCrypt.HashPassword(userDto.Password),
                Role = userDto.Role
            };
        }
        else
        {
            return BadRequest("Invalid role.");
        }

        try
        {
            await _userRepository.CreateUserAsync(user);
            return Ok("User registered successfully.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
            return StatusCode(500, "An internal server error occurred.");
        }
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginDto userLoginDto)
    {
        var user = await _userRepository.GetUserByEmailAsync(userLoginDto.Email);

        if (user == null || !BCrypt.Net.BCrypt.Verify(userLoginDto.Password, user.Password))
        {
            return Ok(new { success = false, message = "The password or email is invalid." });
        }

        var token = GenerateJwtToken(user.Id.ToString(), user.Role);

        var cookieOptions = new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.Lax,
            Expires = DateTime.UtcNow.AddMinutes(60)
        };

        Response.Cookies.Append("AuthToken", token, cookieOptions);

        return Ok(new
        {
            Message = "Login successful, token stored in cookies.",
            Role = user.Role
        });
    }

    private string GenerateJwtToken(string userId, string role)
    {
        var key = _configuration["Jwt:Key"];
        if (string.IsNullOrEmpty(key))
        {
            throw new InvalidOperationException("JWT Key is not configured.");
        }

        var issuer = _configuration["Jwt:Issuer"];
        var audience = _configuration["Jwt:Audience"];

        var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
        var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

        var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Sub, userId),
            new Claim(ClaimTypes.NameIdentifier, userId),
            new Claim(ClaimTypes.Role, role)
        };

        var token = new JwtSecurityToken(
            issuer: issuer,
            audience: audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(60),
            signingCredentials: credentials
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    [HttpGet("profile")]
    [Authorize]
    public async Task<IActionResult> GetProfile()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier); // Extract user ID from token
        var role = User.FindFirstValue(ClaimTypes.Role);

        if (string.IsNullOrEmpty(userId))
        {
            return Unauthorized("User ID not found in token.");
        }

        try
        {
            // Use GetUserByIdAsync to get user data
            var user = await _userRepository.GetUserByIdAsync(userId); // Fetch user by ID (not email)
            if (user == null)
            {
                return NotFound("User not found.");
            }

            return Ok(new
            {
                Message = "This is a protected endpoint.",
                UserId = user.Id,
                Name = user.Name,
                Email = user.Email,
                Role = user.Role
            });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
            return StatusCode(500, "An internal server error occurred.");
        }
    }
}
