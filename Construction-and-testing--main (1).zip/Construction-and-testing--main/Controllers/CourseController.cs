using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.Threading.Tasks;

[ApiController]
[Route("api/[controller]")]
public class CourseController : ControllerBase
{
    private readonly CourseRepository _courseRepository;
    private readonly IConfiguration _configuration;

    public CourseController(CourseRepository courseRepository, IConfiguration configuration)
    {
        _courseRepository = courseRepository;
        _configuration = configuration;
    }

    [HttpPost("create")]
    [Authorize(Roles = "Instructor")]
    public async Task<IActionResult> CreateCourse([FromBody] CreateCourseDto courseDto)
    {
        if (courseDto == null)
            return BadRequest("Course data is required.");

        var instructorId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(instructorId))
            return Unauthorized("Invalid instructor ID.");

        var existingCourse = await _courseRepository.GetCourseByNameAsync(courseDto.Name);
        if (existingCourse != null)
            return Conflict("Course with this name already exists.");

        var course = new Course
        {
            Name = courseDto.Name,
            Description = courseDto.Description,
            InstructorId = instructorId,
            DateCreated = DateTime.UtcNow
        };

        await _courseRepository.CreateCourseAsync(course);
        return CreatedAtAction(nameof(GetCourseById), new { courseId = course.Id }, course);
    }

    [HttpGet("list")]
    [Authorize]
    public async Task<IActionResult> GetAllCourses()
    {
        var courses = await _courseRepository.GetAllCoursesAsync();
        return courses == null || !courses.Any() ? NotFound("No courses available.") : Ok(courses);
    }

    [HttpGet("{courseId}")]
    [Authorize]
    public async Task<IActionResult> GetCourseById(string courseId)
    {
        var course = await _courseRepository.GetCourseByIdAsync(courseId);
        return course == null ? NotFound("Course not found.") : Ok(course);
    }

    [HttpPut("update/{courseId}")]
    [Authorize(Roles = "Instructor")]
    public async Task<IActionResult> UpdateCourse(string courseId, [FromBody] UpdateCourseDto courseDto)
    {
        var existingCourse = await _courseRepository.GetCourseByIdAsync(courseId);
        if (existingCourse == null)
        {
            return NotFound("Course not found.");
        }

        var instructorId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (existingCourse.InstructorId != instructorId)
        {
            return Unauthorized("You are not authorized to update this course.");
        }

        existingCourse.Name = courseDto.Name ?? existingCourse.Name;
        existingCourse.Description = courseDto.Description ?? existingCourse.Description;

        await _courseRepository.UpdateCourseAsync(courseId, existingCourse);
        return Ok(existingCourse);
    }

    [HttpDelete("delete/{courseId}")]
    [Authorize(Roles = "Instructor")]
    public async Task<IActionResult> DeleteCourse(string courseId)
    {
        var existingCourse = await _courseRepository.GetCourseByIdAsync(courseId);
        if (existingCourse == null)
            return NotFound("Course not found.");

        var instructorId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (existingCourse.InstructorId != instructorId)
            return Unauthorized("You are not authorized to delete this course.");

        await _courseRepository.DeleteCourseAsync(courseId);
        return NoContent();
    }

    [HttpPost("subscribe")]
    [Authorize(Roles = "Student")]
    public async Task<IActionResult> SubscribeToCourse([FromBody] SubscribeCourseDto subscribeCourseDto)
    {
        if (subscribeCourseDto == null || string.IsNullOrEmpty(subscribeCourseDto.CourseId))
            return BadRequest("Course ID is required.");

        var studentId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(studentId))
            return Unauthorized("Invalid student ID.");

        var course = await _courseRepository.GetCourseByIdAsync(subscribeCourseDto.CourseId);
        if (course == null)
            return NotFound("Course not found.");

        var isAlreadySubscribed = await _courseRepository.IsStudentSubscribedToCourseAsync(studentId, subscribeCourseDto.CourseId);
        if (isAlreadySubscribed)
            return Conflict("You are already subscribed to this course.");

        await _courseRepository.SubscribeStudentToCourseAsync(studentId, subscribeCourseDto.CourseId);
        return Ok("Subscribed to course successfully.");
    }

    [HttpGet("subscription-count/{courseId}")]
    [Authorize]
    public async Task<IActionResult> GetCourseSubscriptionCount(string courseId)
    {
        if (string.IsNullOrEmpty(courseId))
            return BadRequest("Course ID is required.");

        var course = await _courseRepository.GetCourseByIdAsync(courseId);
        if (course == null)
            return NotFound("Course not found.");

        try
        {
            var subscriptionCount = await _courseRepository.GetSubscriptionCountForCourseAsync(courseId);
            return Ok(new { CourseId = courseId, SubscriptionCount = subscriptionCount });
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }
}
