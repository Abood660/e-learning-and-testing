using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Linq;
using System.Threading.Tasks;
[ApiController]
[Route("api/[controller]")]
public class LessonController : ControllerBase
{
    private readonly LessonRepository _lessonRepository;
    private readonly IConfiguration _configuration;

    public LessonController(LessonRepository lessonRepository, IConfiguration configuration)
    {
        _lessonRepository = lessonRepository;
        _configuration = configuration;
    }

    // Create Lesson
    [HttpPost("create")]
    [Authorize(Roles = "Instructor")]
    public async Task<IActionResult> CreateLesson([FromBody] CreateLessonDto lessonDto)
    {
        if (lessonDto == null)
        {
            return BadRequest("Lesson data is required.");
        }

        var lesson = new Lesson
        {
            Title = lessonDto.Title,
            Url = lessonDto.Url,
            CourseId = lessonDto.CourseId,
            DateCreated = DateTime.UtcNow
        };

        try
        {
            await _lessonRepository.CreateLessonAsync(lesson);
            return CreatedAtAction(nameof(GetLessonById), new { lessonId = lesson.Id }, lesson);
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }

    // Get Lessons by CourseId
    [HttpGet("list/{courseId}")]
    [Authorize]
    public async Task<IActionResult> GetLessonsByCourseId(string courseId)
    {
        try
        {
            var lessons = await _lessonRepository.GetLessonsByCourseIdAsync(courseId);
            if (lessons == null || !lessons.Any())
            {
                return NotFound("No lessons found for this course.");
            }

            return Ok(lessons);
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }

    // Get Lesson by Id
    [HttpGet("{lessonId}")]
    [Authorize]
    public async Task<IActionResult> GetLessonById(string lessonId)
    {
        try
        {
            var lesson = await _lessonRepository.GetLessonByIdAsync(lessonId);
            if (lesson == null)
            {
                return NotFound("Lesson not found.");
            }

            return Ok(lesson);
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }

    // Update Lesson
    [HttpPut("update/{lessonId}")]
    [Authorize(Roles = "Instructor")]
    public async Task<IActionResult> UpdateLesson(string lessonId, [FromBody] UpdateLessonDto lessonDto)
    {
        try
        {
            var existingLesson = await _lessonRepository.GetLessonByIdAsync(lessonId);
            if (existingLesson == null)
            {
                return NotFound("Lesson not found.");
            }

            existingLesson.Title = lessonDto.Title ?? existingLesson.Title;
            existingLesson.Url = lessonDto.Url ?? existingLesson.Url;

            await _lessonRepository.UpdateLessonAsync(lessonId, existingLesson);
            return Ok(existingLesson);
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }

    // Delete Lesson
    [HttpDelete("delete/{lessonId}")]
    [Authorize(Roles = "Instructor")]
    public async Task<IActionResult> DeleteLesson(string lessonId)
    {
        try
        {
            var existingLesson = await _lessonRepository.GetLessonByIdAsync(lessonId);
            if (existingLesson == null)
            {
                return NotFound("Lesson not found.");
            }

            await _lessonRepository.DeleteLessonAsync(lessonId);
            return NoContent();
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }
}
