import React, { useState, useEffect, useCallback } from "react";
import styled from "styled-components";
import { useParams } from "react-router-dom";

const Container = styled.div`
  padding: 2rem;
  background-color: #f5f5f5;
  color: #333;
  min-height: 100vh;
`;

const LessonList = styled.div`
  margin-top: 2rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const LessonCard = styled.div`
  background: #fff;
  padding: 1rem;
  border-radius: 10px;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const Title = styled.h1`
  color: #333;
  margin-bottom: 2rem;
`;

const SubTitle = styled.h2`
  color: #555;
  margin-bottom: 1.5rem;
`;

const ErrorMessage = styled.p`
  color: red;
  padding: 1rem;
  background-color: #ffe6e6;
  border-radius: 5px;
  margin-bottom: 1rem;
`;

const LessonTitle = styled.h3`
  color: #0a9396;
  margin-bottom: 0.5rem;
`;

const LessonUrl = styled.p`
  color: #666;
  font-size: 0.9rem;
`;

const LoadingSpinner = styled.div`
  display: inline-block;
  width: 50px;
  height: 50px;
  border: 3px solid #f3f3f3;
  border-top: 3px solid #0a9396;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 2rem auto;

  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`;

const Showlessons = () => {
  const { courseId } = useParams();
  const [lessons, setLessons] = useState([]);
  const [courseName, setCourseName] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  const fetchCourseAndLessons = useCallback(async () => {
    setIsLoading(true);
    setError("");
    try {
      // Fetch course details
      console.log(`Fetching course details for courseId: ${courseId}`);
      const courseResponse = await fetch(
        `http://localhost:7222/api/Course/${courseId}`,
        {
          method: "GET",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("Course response:", courseResponse);

      if (!courseResponse.ok) {
        throw new Error("Failed to fetch course details");
      }

      const courseData = await courseResponse.json();
      setCourseName(courseData.name);
      console.log("Fetched course data:", courseData);

      // Fetch lessons
      console.log(`Fetching lessons for courseId: ${courseId}`);
      const lessonResponse = await fetch(
        `http://localhost:7222/api/Lesson/list/${courseId}`,
        {
          method: "GET",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("Lesson response:", lessonResponse);

      if (!lessonResponse.ok) {
        throw new Error("Failed to fetch lessons");
      }

      const lessonData = await lessonResponse.json();
      setLessons(lessonData);
      console.log("Fetched lessons data:", lessonData);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [courseId]);

  useEffect(() => {
    fetchCourseAndLessons();
  }, [fetchCourseAndLessons]);

  if (isLoading) {
    return (
      <Container data-cy="lessons-container">
        <Title data-cy="course-title">Loading Course Details...</Title>
        <LoadingSpinner data-cy="loading-spinner" />
      </Container>
    );
  }

  return (
    <Container data-cy="lessons-container">
      <Title data-cy="course-title">Lessons for Course: {courseName}</Title>
      {error && <ErrorMessage data-cy="error-message">{error}</ErrorMessage>}
      <LessonList data-cy="lesson-list">
        <SubTitle>Lessons</SubTitle>
        {lessons.length === 0 ? (
          <ErrorMessage data-cy="no-lessons-message">
            No lessons available for this course.
          </ErrorMessage>
        ) : (
          lessons.map((lesson) => (
            <LessonCard key={lesson.id} data-cy={`lesson-card-${lesson.id}`}>
              <div>
                <LessonTitle data-cy={`lesson-title-${lesson.id}`}>
                  {lesson.title}
                </LessonTitle>
                <LessonUrl data-cy={`lesson-url-${lesson.id}`}>
                  {lesson.url}
                </LessonUrl>
              </div>
            </LessonCard>
          ))
        )}
      </LessonList>
    </Container>
  );
};

export default Showlessons;
