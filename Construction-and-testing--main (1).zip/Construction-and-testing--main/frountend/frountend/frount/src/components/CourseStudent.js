import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";

const Container = styled.div`
    padding: 2rem;
    background-color: #f5f5f5;
    color: #333;
    min-height: 100vh;
`;

const CourseList = styled.div`
    margin-top: 2rem;
    display: flex;
    flex-direction: column;
    gap: 1rem;
`;

const Button = styled.button`
    padding: 0.8rem;
    background-color: ${(props) => (props.disabled ? "#ccc" : "#0a9396")};
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: ${(props) => (props.disabled ? "not-allowed" : "pointer")};
    transition: background 0.3s;
    font-size: 1rem;

    &:hover {
        background-color: ${(props) => (props.disabled ? "#ccc" : "#005f73")};
    }
`;

const CourseCard = styled.div`
    background: #fff;
    padding: 1rem;
    border-radius: 10px;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
`;

const CourseStudent = () => {
    const navigate = useNavigate();
    const [courses, setCourses] = useState([]);
    const [error, setError] = useState("");

    const fetchCourses = async () => {
        try {
            const response = await fetch("http://localhost:7222/api/Course/list", {
                method: "GET",
                credentials: "include",
            });

            if (!response.ok) throw new Error("Failed to fetch courses");

            const data = await response.json();
            setCourses(data); // Assuming `data` includes an `isSubscribed` field
        } catch (err) {
            setError(err.message);
        }
    };

    const handleSubscribe = async (courseId) => {
        try {
            const response = await fetch(`http://localhost:7222/api/Course/subscribe`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({ courseId }),
            });

            if (!response.ok) throw new Error("Failed to subscribe to course");

            // Update the subscription status in the courses list
            setCourses((prevCourses) =>
                prevCourses.map((course) =>
                    course.id === courseId ? { ...course, isSubscribed: true } : course
                )
            );
        } catch (err) {
            setError(err.message);
        }
    };

    const handleShowLessons = (courseId) => {
        navigate(`/lessons/student/${courseId}`);
    };

    useEffect(() => {
        fetchCourses();
    }, []);

    return (
        <Container>
            <Button onClick={() => navigate("/profile")}>Go to Profile</Button>

            <h1>Course List</h1>
            {error && <p style={{ color: "red" }}>{error}</p>}
            <CourseList>
                <h2>Available Courses</h2>
                {courses.map((course) => (
                    <CourseCard key={course.id}>
                        <div>
                            <h3>{course.name}</h3>
                            <p>{course.description}</p>
                        </div>
                        <div>
                            {course.isSubscribed ? (
                                <Button onClick={() => handleShowLessons(course.id)}>
                                    Show Lessons
                                </Button>
                            ) : (
                                <Button onClick={() => handleSubscribe(course.id)}>
                                    Subscribe
                                </Button>
                            )}
                        </div>
                    </CourseCard>
                ))}
            </CourseList>
        </Container>
    );
};

export default CourseStudent;
