import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";

const FormContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-color: #f5f5f5;
  color: #333;
`;

const Form = styled.form`
  background: #fff;
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
  display: flex;
  flex-direction: column;
  gap: 1rem;
  width: 100%;
  max-width: 400px;
`;

const Input = styled.input`
  padding: 0.8rem;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 1rem;
  width: 100%;
`;

const Select = styled.select`
  padding: 0.8rem;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 1rem;
  width: 100%;
`;

const Button = styled.button`
  padding: 0.8rem;
  background-color: #0a9396;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background 0.3s;
  font-size: 1rem;
  width: 100%;

  &:hover {
    background-color: #005f73;
  }

  &:disabled {
    background-color: #cccccc;
    cursor: not-allowed;
  }
`;

const ErrorMessage = styled.div`
  color: #dc2626;
  font-size: 0.875rem;
  margin-top: 0.5rem;
  text-align: center;
  role: alert;
`;

const Title = styled.h2`
  margin-bottom: 1.5rem;
  font-size: 1.875rem;
  font-weight: 600;
  text-align: center;
`;

const Register = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [formData, setFormData] = useState({
    Name: "",
    Email: "",
    Password: "",
    Role: "Student",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    console.log(formData);

    try {
      const response = await fetch("http://localhost:7222/api/User/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
        credentials: "include",
      });

      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(errorData || "Registration failed");
      }

      const data = await response.text();
      alert(data);
      navigate("/login");
    } catch (error) {
      console.error("Registration error:", error);
      if (error.message.includes("Failed to fetch")) {
        console.log("Data sent to backend:", JSON.stringify(formData));
        setError(
          "Unable to connect to the server. Please check your connection and try again."
        );
      } else if (error.message.includes("Network Error")) {
        setError(
          "Network error. Please check your internet connection and try again."
        );
      } else {
        setError(error.message || "An unexpected error occurred.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <FormContainer>
      <Form onSubmit={handleSubmit}>
        <Title>Register</Title>
        <Input
          type="text"
          name="Name"
          placeholder="Name"
          value={formData.Name}
          onChange={handleChange}
          required
          disabled={isLoading}
        />
        <Input
          type="email"
          name="Email"
          placeholder="Email"
          value={formData.Email}
          onChange={handleChange}
          required
          disabled={isLoading}
        />
        <Input
          type="password"
          name="Password"
          placeholder="Password"
          value={formData.Password}
          onChange={handleChange}
          required
          disabled={isLoading}
          minLength={6}
        />
        <Select
          name="Role"
          value={formData.Role}
          onChange={handleChange}
          disabled={isLoading}>
          <option value="Student">Student</option>
          <option value="Instructor">Instructor</option>
        </Select>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Registering..." : "Register"}
        </Button>
        {error && <ErrorMessage role="alert">{error}</ErrorMessage>}
      </Form>
    </FormContainer>
  );
};

export default Register;
