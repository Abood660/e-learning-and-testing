import React, { useState, useEffect, useCallback } from "react";
import styled from "styled-components";
import { useParams } from "react-router-dom"; // To access courseId from URL

const Container = styled.div`
    padding: 2rem;
    background-color: #f5f5f5;
    color: #333;
    min-height: 100vh;
`;

const Form = styled.form`
    background: #fff;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    display: flex;
    flex-direction: column;
    gap: 1rem;
    margin-bottom: 2rem;
`;

const Input = styled.input`
    padding: 0.8rem;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 1rem;
`;

const Button = styled.button`
    padding: 0.8rem;
    background-color: #0a9396;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s;
    font-size: 1rem;

    &:hover {
        background-color: #005f73;
    }
`;

const LessonList = styled.div`
    margin-top: 2rem;
    display: flex;
    flex-direction: column;
    gap: 1rem;
`;

const LessonCard = styled.div`
    background: #fff;
    padding: 1rem;
    border-radius: 10px;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
`;

const LessonManagement = () => {
    const { courseId } = useParams();
    const [lessons, setLessons] = useState([]);
    const [courseName, setCourseName] = useState(""); 
    const [lessonData, setLessonData] = useState({ title: "", url: "" });
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");


    const fetchCourseAndLessons = useCallback(async () => {
        try {
            const courseResponse = await fetch(`http://localhost:7222/api/Course/${courseId}`, {
                method: "GET",
                credentials: "include",
            });

            if (!courseResponse.ok) throw new Error("Failed to fetch course details");

            const courseData = await courseResponse.json();
            setCourseName(courseData.name); 

            const lessonResponse = await fetch(`http://localhost:7222/api/Lesson/list/${courseId}`, {
                method: "GET",
                credentials: "include",
            });

            if (!lessonResponse.ok) throw new Error("Failed to fetch lessons");

            const lessonData = await lessonResponse.json();
            setLessons(lessonData);  

        } catch (err) {
            setError(err.message);
        }
    }, [courseId]);

    useEffect(() => {
        fetchCourseAndLessons();
    }, [fetchCourseAndLessons]);

    const handleCreateLesson = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch(`http://localhost:7222/api/Lesson/create`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({
                    Title: lessonData.title,
                    Url: lessonData.url,
                    CourseId: courseId,
                }),
            });

            if (!response.ok) throw new Error("Error creating lesson");
            setSuccess("Lesson created successfully!");
            setLessonData({ title: "", url: "" });
            fetchCourseAndLessons();
        } catch (err) {
            setError(err.message);
        }
    };

    return (
        <Container>
            <h1>Lesson Management for Course: {courseName || "Loading..."}</h1>
            {error && <p style={{ color: "red" }}>{error}</p>}
            {success && <p style={{ color: "green" }}>{success}</p>}

            <Form onSubmit={handleCreateLesson}>
                <Input
                    type="text"
                    name="title"
                    placeholder="Lesson Title"
                    value={lessonData.title}
                    onChange={(e) => setLessonData({ ...lessonData, title: e.target.value })}
                    required
                />
                <Input
                    type="text"
                    name="url"
                    placeholder="Lesson URL"
                    value={lessonData.url}
                    onChange={(e) => setLessonData({ ...lessonData, url: e.target.value })}
                    required
                />
                <Button type="submit">Create Lesson</Button>
            </Form>

            <LessonList>
                <h2>Lessons</h2>
                {lessons.map((lesson) => (
                    <LessonCard key={lesson.id}>
                        <div>
                            <h3>{lesson.title}</h3>
                            <p>{lesson.url}</p>
                        </div>
                    </LessonCard>
                ))}
            </LessonList>
        </Container>
    );
};

export default LessonManagement;
