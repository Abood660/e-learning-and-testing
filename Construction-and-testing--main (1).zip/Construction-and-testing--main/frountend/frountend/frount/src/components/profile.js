import React, { useState, useEffect } from 'react';
import styled from 'styled-components';

const Container = styled.div`
    padding: 2rem;
    background-color: #f5f5f5;
    color: #333;
    min-height: 100vh;
`;

const ProfileCard = styled.div`
    background: #fff;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
`;

const Profile = () => {
    const [profileData, setProfileData] = useState(null);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const response = await fetch('http://localhost:7222/api/User/profile', {
                    method: 'GET',
                    credentials: 'include', 
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.message || 'Failed to fetch profile data');
                }

                const data = await response.json();
                setProfileData(data);
            } catch (err) {
                console.error(err.message);
                setError(err.message || 'Error fetching profile');
            }
        };

        fetchProfile();
    }, []);

    return (
        <Container>
            <h1>User Profile</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            {profileData ? (
                <ProfileCard>
                    <h2>Name: {profileData.name}</h2>
                    <p>Email: {profileData.email}</p>
                    <p>Role: {profileData.role}</p>
                </ProfileCard>
            ) : (
                <p>Loading...</p>
            )}
        </Container>
    );
};

export default Profile;
