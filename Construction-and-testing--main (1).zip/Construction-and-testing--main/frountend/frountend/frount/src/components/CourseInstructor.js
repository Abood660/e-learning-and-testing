import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";

const Container = styled.div`
    padding: 2rem;
    background-color: #f5f5f5;
    color: #333;
    min-height: 100vh;
`;

const Form = styled.form`
    background: #fff;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    display: flex;
    flex-direction: column;
    gap: 1rem;
    margin-bottom: 2rem;
`;

const Input = styled.input`
    padding: 0.8rem;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 1rem;
`;

const Button = styled.button`
    padding: 0.8rem;
    background-color: #0a9396;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s;
    font-size: 1rem;

    &:hover {
        background-color: #005f73;
    }
`;

const ErrorMessage = styled.p`
    color: red;
    font-size: 0.9rem;
`;

const SuccessMessage = styled.p`
    color: green;
    font-size: 0.9rem;
`;

const CourseList = styled.div`
    margin-top: 2rem;
    display: flex;
    flex-direction: column;
    gap: 1rem;
`;

const CourseCard = styled.div`
    background: #fff;
    padding: 1rem;
    border-radius: 10px;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
`;

const CourseInstructor = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({ name: "", description: "" });
    const [updateData, setUpdateData] = useState(null);
    const [courses, setCourses] = useState([]);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [subscriptions, setSubscriptions] = useState({});

    const fetchCourses = async () => {
        try {
            const response = await fetch("http://localhost:7222/api/Course/list", {
                method: "GET",
                credentials: "include",
            });

            if (!response.ok) throw new Error("Failed to fetch courses");

            const data = await response.json();
            setCourses(data);
            fetchSubscriptions(data);
        } catch (err) {
            console.error(err.message);
        }
    };

    const fetchSubscriptions = async (courses) => {
        try {
            const subscriptionCounts = {};
            for (const course of courses) {
                const response = await fetch(`http://localhost:7222/api/Course/subscription-count/${course.id}`, {
                    method: "GET",
                    credentials: "include",
                });

                if (!response.ok) {
                    subscriptionCounts[course.id] = "N/A";
                    continue;
                }

                const count = await response.json();
                // Ensure the subscription count is a valid string or number
                subscriptionCounts[course.id] = count.subscriptionCount || "N/A";  
            }
            setSubscriptions(subscriptionCounts);
        } catch (err) {
            console.error("Failed to fetch subscriptions:", err.message);
        }
    };

    useEffect(() => {
        fetchCourses();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleCreateCourse = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch("http://localhost:7222/api/Course/create", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify(formData),
            });
            if (!response.ok) throw new Error("Error creating course");
            setSuccess("Course created successfully!");
            setFormData({ name: "", description: "" });
            fetchCourses();
        } catch (err) {
            setError(err.message);
        }
    };

    const handleUpdateCourse = async (e) => {
        e.preventDefault();
        if (!updateData) return;

        const updatePayload = {
            name: updateData.name,
            description: updateData.description,
        };

        try {
            const response = await fetch(`http://localhost:7222/api/Course/update/${updateData.id}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${localStorage.getItem("token")}`, 
                },
                credentials: "include",
                body: JSON.stringify(updatePayload),
            });

            if (!response.ok) {
                const errorData = await response.json();
                console.log("Error response:", errorData);
                throw new Error(errorData.message || "Error updating course");
            }

            setSuccess("Course updated successfully!");
            setUpdateData(null);
            fetchCourses();
        } catch (err) {
            setError(err.message);
        }
    };

    const handleDeleteCourse = async (id) => {
        try {
            const response = await fetch(`http://localhost:7222/api/Course/delete/${id}`, {
                method: "DELETE",
                credentials: "include",
            });
            if (!response.ok) throw new Error("Error deleting course");
            setSuccess("Course deleted successfully!");
            fetchCourses();
        } catch (err) {
            setError(err.message);
        }
    };

    const handleManageLessons = (courseId) => {
        navigate(`/lessons/${courseId}`); 
    };

    return (
        <Container>
            <Button onClick={() => navigate("/profile")}>Go to Profile</Button>

            <h1>Course Management</h1>
            {error && <ErrorMessage>{error}</ErrorMessage>}
            {success && <SuccessMessage>{success}</SuccessMessage>}

            {!updateData ? (
                <Form onSubmit={handleCreateCourse}>
                    <Input
                        type="text"
                        name="name"
                        placeholder="Course Name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                    />
                    <Input
                        type="text"
                        name="description"
                        placeholder="Course Description"
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        required
                    />
                    <Button type="submit">Create Course</Button>
                </Form>
            ) : (
                <Form onSubmit={handleUpdateCourse}>
                    <Input
                        type="text"
                        name="name"
                        placeholder="Course Name"
                        value={updateData.name}
                        onChange={(e) => setUpdateData({ ...updateData, name: e.target.value })}
                        required
                    />
                    <Input
                        type="text"
                        name="description"
                        placeholder="Course Description"
                        value={updateData.description}
                        onChange={(e) => setUpdateData({ ...updateData, description: e.target.value })}
                        required
                    />
                    <Button type="submit">Update Course</Button>
                    <Button type="button" onClick={() => setUpdateData(null)}>
                        Cancel
                    </Button>
                </Form>
            )}

            <CourseList>
                <h2>Available Courses</h2>
                {courses.map((course) => (
                    <CourseCard key={course.id}>
                        <div>
                            <h3>{course.name}</h3>
                            <p>{course.description}</p>
                            <p>
                                <strong>Students Subscribed:</strong> 
                                {subscriptions[course.id] !== undefined ? 
                                    subscriptions[course.id] : 
                                    "Loading..."}
                            </p>
                        </div>
                        <div>
                            <Button onClick={() => setUpdateData(course)}>Edit</Button>
                            <Button onClick={() => handleDeleteCourse(course.id)}>Delete</Button>
                            <Button type ="submit" onClick={() => handleManageLessons(course.id)}>Manage Lessons</Button>
                        </div>
                    </CourseCard>
                ))}
            </CourseList>
        </Container>
    );
};

export default CourseInstructor;
