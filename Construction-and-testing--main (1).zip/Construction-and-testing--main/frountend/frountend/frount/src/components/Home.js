
import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const HomeContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background: linear-gradient(135deg, #6dd5ed, #2193b0);
    color: #fff;
    text-align: center;
`;

const NavLinks = styled.div`
    margin-top: 20px;
    a {
        text-decoration: none;
        color: #fff;
        font-weight: bold;
        margin: 0 10px;
        padding: 10px 20px;
        background-color: #005f73;
        border-radius: 5px;
        transition: background 0.3s;
    }
    a:hover {
        background-color: #0a9396;
    }
`;

const Home = () => {
    return (
        <HomeContainer>
            <h1>Welcome to BrainBuddies E-Learning Platform</h1>
            <p>Learn from the best instructors and improve your skills today.</p>
            <NavLinks>
                <Link to="/register">Register</Link>
                <Link to="/login">Login</Link>
            </NavLinks>
        </HomeContainer>
    );
};

export default Home;
