
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './components/Home.js';
import Login from './components/login.js';
import Register from './components/Register.js';
import CourseInstructor from './components/CourseInstructor.js';
import CourseStudent from './components/CourseStudent.js';
import Profile from './components/profile.js';
import LessonManagement from './components/LessonManagement.js';
import Showlessons from './components/showlessons.js';
const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/register" element={<Register />} />
                <Route path="/login" element={<Login />} />
                <Route path="/course/Student" element={<CourseStudent />} />
                <Route path="/course/Instructor" element={<CourseInstructor />} />
               <Route path="/profile" element={<Profile />} />
               <Route path="/lessons/:courseId" element={< LessonManagement/>} />
               <Route path="/lessons/student/:courseId" element={< Showlessons/>} />
            </Routes>
        </Router>
    );
};

export default App;