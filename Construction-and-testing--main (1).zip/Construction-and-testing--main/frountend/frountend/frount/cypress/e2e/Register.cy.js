/* eslint-disable no-undef */
describe("Register Tests", () => {
  it("should register a new user with valid credentials", () => {
    // Mock backend response for valid registration
    cy.intercept("POST", "http://localhost:7222/api/User/register", {
      statusCode: 200,
      body: "Registration successful",
    }).as("registerRequest");
    cy.visit("http://localhost:3000/register", { timeout: 10000 });
    cy.get('input[name="Name"]').should("be.visible").type("Test User");
    cy.get('input[name="Email"]')
      .should("be.visible")
      .type("testuser@example.com");
    cy.get('input[name="Password"]').should("be.visible").type("password123");
    cy.get('select[name="Role"]').should("be.visible").select("Student");
    cy.get('button[type="submit"]').click();
    cy.wait("@registerRequest");

    cy.url().should("include", "/login");
    cy.contains("Login");
  });

  it("should display an error message for failed registration", () => {
    cy.intercept("POST", "http://localhost:7222/api/User/register", {
      statusCode: 409,
      body: "User with this email already exists.",
    }).as("registerRequest");
    cy.visit("http://localhost:3000/register", { timeout: 10000 });
    cy.get('input[name="Name"]').should("be.visible").type("Test User");
    cy.get('input[name="Email"]')
      .should("be.visible")
      .type("existinguser@example.com");
    cy.get('input[name="Password"]').should("be.visible").type("password123");
    cy.get('select[name="Role"]').should("be.visible").select("Student");
    cy.get('button[type="submit"]').click();
    cy.wait("@registerRequest");

    cy.log("Checking for error message");
    cy.get('[role="alert"]')
      .should("exist")
      .and("contain.text", "User with this email already exists.");
  });
});
