/* eslint-disable no-undef */
describe("Profile Tests", () => {
  it("should display profile data", () => {
    cy.intercept("GET", "http://localhost:7222/api/User/profile", {
      statusCode: 200,
      body: {
        name: "Test User",
        email: "testuser@example.com",
        role: "Student",
      },
    }).as("profileRequest");

    cy.visit("http://localhost:3000/profile", { timeout: 10000 });

    cy.wait("@profileRequest");
    cy.get("h2").should("contain.text", "Name: Test User");
    cy.get("p").should("contain.text", "Email: testuser@example.com");
    cy.get("p").should("contain.text", "Role: Student");
  });

  it("should display an error message if profile fetch fails", () => {
    cy.intercept("GET", "http://localhost:7222/api/User/profile", {
      statusCode: 500,
      body: {
        message: "Failed to fetch profile data",
      },
    }).as("profileRequest");
    cy.visit("http://localhost:3000/profile", { timeout: 10000 });
    cy.wait("@profileRequest");
    cy.get("p").should("contain.text", "Failed to fetch profile data");
  });
});
