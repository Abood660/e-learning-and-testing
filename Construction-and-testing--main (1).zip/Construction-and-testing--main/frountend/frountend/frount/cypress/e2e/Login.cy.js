/* eslint-disable no-undef */
describe("Login Tests", () => {
  it("should allow login with valid credentials", () => {
    cy.intercept("POST", "http://localhost:7222/api/User/login", {
      statusCode: 200,
      body: {
        role: "Instructor",
      },
    }).as("loginRequest");
    cy.visit("http://localhost:3000/login", { timeout: 10000 });

    // Enter valid email and password
    cy.get('input[name="email"]').should("be.visible").type("test@example.com");
    cy.get('input[name="password"]').should("be.visible").type("password123");
    cy.get('button[type="submit"]').click();

    // Wait for the login request to complete
    cy.wait("@loginRequest");
    cy.url().should("include", "/course/Instructor");
  });

  it("should display an error message for invalid credentials", () => {
    // Mock backend response for invalid login
    cy.intercept("POST", "http://localhost:7222/api/User/login", {
      statusCode: 401,
      body: {
        message: "The password or email is invalid.",
      },
    }).as("loginRequest");
    cy.visit("http://localhost:3000/login", { timeout: 10000 });

    // Enter invalid email and password
    cy.get('input[name="email"]')
      .should("be.visible")
      .type("wronguser@example.com");
    cy.get('input[name="password"]').should("be.visible").type("wrongpassword");
    cy.get('button[type="submit"]').click();

    // Wait for the login request to complete
    cy.wait("@loginRequest");
    cy.log("Checking for error message");
    cy.get('[role="alert"]')
      .should("exist")
      .and("contain.text", "The password or email is invalid.");
  });
});
