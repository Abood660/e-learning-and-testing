/* eslint-disable no-undef */
describe("Show Lessons Tests", () => {
  it("should display course name and lessons successfully", () => {
   
    cy.intercept("GET", "http://localhost:7222/api/Course/1", {
      statusCode: 200,
      body: { id: 1, name: "Introduction to Programming II" },
    }).as("courseRequest");
    cy.intercept("GET", "http://localhost:7222/api/Lesson/list/1", {
      statusCode: 200,
      body: [
        { id: 1, title: "Lesson 1: Basics" },
        { id: 2, title: "Lesson 2: Advanced" },
      ],
    }).as("lessonsRequest");
    cy.visit("http://localhost:3000/lessons/student/1", { timeout: 10000 });

    cy.wait("@courseRequest");
    cy.wait("@lessonsRequest");
    cy.get('[data-cy="course-title"]')
      .should("be.visible")
      .and("contain", "Introduction to Programming II");

    cy.get('[data-cy^="lesson-card-"]').should("have.length", 2);
  });

  it("should display an error message if fetching course fails", () => {
    cy.intercept("GET", "http://localhost:7222/api/Course/1", { statusCode: 500 }).as("courseRequest");
    cy.visit("http://localhost:3000/lessons/student/1", { timeout: 10000 });
    cy.wait("@courseRequest");
    cy.get('[data-cy="error-message"]')
      .should("exist")
      .and("contain.text", "Failed to fetch course details");
  });

  it("should display an error message if fetching lessons fails", () => {
   
    cy.intercept("GET", "http://localhost:7222/api/Course/1", {
      statusCode: 200,
      body: { id: 1, name: "Introduction to Programming II" },
    }).as("courseRequest");
    cy.intercept("GET", "http://localhost:7222/api/Lesson/list/1", { statusCode: 500 }).as("lessonsRequest");
    cy.visit("http://localhost:3000/lessons/student/1", { timeout: 10000 });
    cy.wait("@courseRequest");
    cy.wait("@lessonsRequest");
    cy.get('[data-cy="error-message"]')
      .should("exist")
      .and("contain.text", "Failed to fetch lessons");
  });

  it("should display a message when no lessons are available", () => {
    
    cy.intercept("GET", "http://localhost:7222/api/Course/1", {
      statusCode: 200,
      body: { id: 1, name: "Introduction to Programming II" },
    }).as("courseRequest");
    cy.intercept("GET", "http://localhost:7222/api/Lesson/list/1", { body: [] }).as("lessonsRequest");
    cy.visit("http://localhost:3000/lessons/student/1", { timeout: 10000 });
    cy.wait("@courseRequest");
    cy.wait("@lessonsRequest");

    cy.get('[data-cy="no-lessons-message"]')
      .should("be.visible")
      .and("contain.text", "No lessons available for this course.");
  });
});
