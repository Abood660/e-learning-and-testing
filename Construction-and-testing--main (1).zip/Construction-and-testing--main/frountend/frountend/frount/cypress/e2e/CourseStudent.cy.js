/* eslint-disable no-undef */
describe("CourseStudent Tests", () => {
  beforeEach(() => {
    // Setup intercepts
    cy.intercept("GET", "http://localhost:7222/api/Course/list", {
      statusCode: 200,
      body: [
        {
          id: "1",
          name: "Course 1",
          description: "Description for course 1",
          isSubscribed: false,
        },
        {
          id: "2",
          name: "Course 2",
          description: "Description for course 2",
          isSubscribed: true,
        },
      ],
    }).as("coursesRequest");

    cy.intercept("POST", "http://localhost:7222/api/Course/subscribe", {
      statusCode: 200,
      body: { message: "Subscription successful" },
    }).as("subscribeRequest");
  });

  it("should display course list", () => {
    // Visit the course student page
    cy.visit("http://localhost:3000/course/Student", { timeout: 10000 });

    // Wait for the request to complete
    cy.wait("@coursesRequest").its("response.statusCode").should("eq", 200);

    // Assert course list is displayed correctly
    cy.get("h1").should("contain.text", "Course List");
    cy.get("h2").should("contain.text", "Available Courses");
    cy.get("h3").should("contain.text", "Course 1");
    cy.get("h3").should("contain.text", "Course 2");
    cy.get("p").should("contain.text", "Description for course 1");
    cy.get("p").should("contain.text", "Description for course 2");
  });

  it("should subscribe to a course", () => {
    // Visit the course student page
    cy.visit("http://localhost:3000/course/Student", { timeout: 10000 });

    // Wait for the initial request to complete
    cy.wait("@coursesRequest").its("response.statusCode").should("eq", 200);

    // Click the Subscribe button for Course 1
    cy.get("button").contains("Subscribe").click();

    // Wait for the subscribe request to complete
    cy.wait("@subscribeRequest").its("response.statusCode").should("eq", 200);

    // Assert the Subscribe button is replaced with Show Lessons button
    cy.get("button").contains("Show Lessons").should("be.visible");
  });

  it("should navigate to profile page", () => {
    // Visit the course student page
    cy.visit("http://localhost:3000/course/Student", { timeout: 10000 });

    // Click the Go to Profile button
    cy.get("button").contains("Go to Profile").click();

    // Assert the URL is correct
    cy.url().should("include", "/profile");
  });

  it("should navigate to lessons page when Show Lessons button is clicked", () => {
    // Visit the course student page
    cy.visit("http://localhost:3000/course/Student", { timeout: 10000 });

    // Wait for the initial request to complete
    cy.wait("@coursesRequest").its("response.statusCode").should("eq", 200);

    // Click the Show Lessons button for Course 2
    cy.get("button").contains("Show Lessons").click();

    // Assert the URL is correct
    cy.url().should("include", "/lessons/student/2");
  });

  it("should display an error message if fetching courses fails", () => {
    // Mock backend response for failed courses fetch
    cy.intercept("GET", "http://localhost:7222/api/Course/list", {
      statusCode: 500,
      body: {
        message: "Failed to fetch courses",
      },
    }).as("coursesRequest");

    // Visit the course student page
    cy.visit("http://localhost:3000/course/Student", { timeout: 10000 });

    // Wait for the request to complete
    cy.wait("@coursesRequest").its("response.statusCode").should("eq", 500);

    // Assert error message is displayed
    cy.get("p").should("contain.text", "Failed to fetch courses");
  });
});
