/* eslint-disable no-undef */
describe("LessonManagement Tests", () => {
  beforeEach(() => {
    // Setup intercepts
    cy.intercept("GET", "http://localhost:7222/api/Course/list", {
      statusCode: 200,
      body: [
        {
          id: "1",
          name: "Test Course",
          description: "Description for Test Course",
         
        },
      ],
    }).as("coursesRequest");

    cy.intercept("GET", "http://localhost:7222/api/Lesson/list/1", {
      statusCode: 200,
      body: [
        { id: "1", title: "Lesson 1", url: "http://lesson1.com" },
        
      ],
    }).as("lessonsRequest");

    cy.intercept("POST", "http://localhost:7222/api/Lesson/create", (req) => {
      req.reply({
        statusCode: 201,
        body: {
          id: "3",
          title: "New Lesson",
          url: "http://newlesson.com",
          courseId: "1",
        },
      });
    }).as("createLessonRequest");
  });
  it("should create a new lesson", () => {
    // Visit the course instructor page
    cy.visit("http://localhost:3000/course/Instructor", { timeout: 10000 });
    
    cy.get('button[type="submit"]').contains("Manage Lessons").click();
    
    // Wait for the lessons request to complete
    
    cy.url().should("include", "/lessons/1");
    
    cy.get('input[name="title"]').type("New Lesson");
    cy.get('input[name="url"]').type("http://newlesson.com");
    cy.get('button[type="submit"]').contains("Create Lesson").click();

 
    cy.wait("@createLessonRequest").its("response.statusCode").should("eq", 201);


    // Assert the new lesson is displayed in the list
    cy.get("h3").should("contain.text", "New Lesson");
    cy.get("p").should("contain.text", "http://newlesson.com");
  });
  

  it("should navigate to lesson management from course instructor page", () => {
    // Visit the course instructor page
    cy.visit("http://localhost:3000/course/Instructor", { timeout: 10000 });

    // Wait for course request
    cy.wait("@coursesRequest").its("response.statusCode").should("eq", 200);

    // Click on Manage Lessons button for the test course
    cy.get('button[type="submit"]').contains("Manage Lessons").click();

    // Assert redirection to the correct lessons management page
    cy.url().should("include", "/lessons/1");
    cy.get("h1").should(
      "contain.text",
      "Lesson Management for Course:"
    );
  });

  it("should display course name and lessons", () => {
    // Visit the lesson management page through course instructor navigation
    cy.visit("http://localhost:3000/course/Instructor", { timeout: 10000 });

    cy.wait("@coursesRequest").its("response.statusCode").should("eq", 200);
    // Navigate to lesson management
    cy.get('button[type="submit"]').contains("Manage Lessons").click();

    // Wait for the lessons request to complete
    cy.wait("@lessonsRequest").its("response.statusCode").should("eq", 200);

    // Assert course name and lessons are displayed correctly
    cy.get("h1").should(
      "contain.text",
      "Lesson Management for Course:"
    );
    cy.get("h3").should("contain.text", "Lesson 1");
    cy.get("p").should("contain.text", "http://lesson1.com");
 
  });

  
});
