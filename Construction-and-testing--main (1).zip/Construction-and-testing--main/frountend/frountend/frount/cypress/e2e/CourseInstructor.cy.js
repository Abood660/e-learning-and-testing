/* eslint-disable no-undef */
describe("CourseInstructor Tests", () => {
  beforeEach(() => {
    // Setup intercepts
    cy.intercept("GET", "http://localhost:7222/api/Course/list", (req) => {
      req.reply({
        statusCode: 200,
        body: [
          {
            id: "1",
            name: "Course 1",
            description: "Description for course 1",
          },
        ],
      });
      console.log("Intercepted coursesRequest:", req);
    }).as("coursesRequest");

    cy.intercept("POST", "http://localhost:7222/api/Course/create", (req) => {
      req.reply({
        statusCode: 201,
        body: { message: "Course created successfully" },
      });
      console.log("Intercepted createCourseRequest:", req);
    }).as("createCourseRequest");

    cy.intercept("PUT", "http://localhost:7222/api/Course/update/1", (req) => {
      req.reply({
        statusCode: 200,
        body: { message: "Course updated successfully" },
      });
      console.log("Intercepted updateCourseRequest:", req);
    }).as("updateCourseRequest");

    cy.intercept(
      "DELETE",
      "http://localhost:7222/api/Course/delete/1",
      (req) => {
        req.reply({
          statusCode: 200,
          body: { message: "Course deleted successfully" },
        });
        console.log("Intercepted deleteCourseRequest:", req);
      }
    ).as("deleteCourseRequest");

    cy.intercept(
      "GET",
      "http://localhost:7222/api/Course/subscription-count/1",
      (req) => {
        req.reply({
          statusCode: 200,
          body: 10, // Mock subscription count
        });
        console.log("Intercepted subscriptionCountRequest:", req);
      }
    ).as("subscriptionCountRequest");
  });

  it("should display course list with subscription counts", () => {
    // Visit the course instructor page
    cy.visit("http://localhost:3000/course/Instructor", { timeout: 10000 });

    // Wait for the requests to complete
    cy.wait("@coursesRequest").then((interception) => {
      console.log("Intercepted coursesRequest:", interception);
    });
    cy.wait("@subscriptionCountRequest").then((interception) => {
      console.log("Intercepted subscriptionCountRequest:", interception);
    });

    // Assert course list is displayed correctly with subscription counts
    cy.get("h1").should("contain.text", "Course Management");
    cy.get("h2").should("contain.text", "Available Courses");
    cy.get("h3").should("contain.text", "Course 1");
    
    cy.get("p").contains("Description for course 1").should("be.visible");
    
    cy.get("p").contains("Students Subscribed:").should("be.visible");
  });

  it("should create a new course", () => {
    // Visit the course instructor page
    cy.visit("http://localhost:3000/course/Instructor", { timeout: 10000 });

    // Wait for the request to complete
    cy.wait("@coursesRequest").its("response.statusCode").should("eq", 200);

    // Fill in the course creation form
    cy.get('input[name="name"]').type("New Course");
    cy.get('input[name="description"]').type("Description for new course");
    cy.get('button[type="submit"]').contains("Create Course").click();

    // Wait for the create course request to complete
    cy.wait("@createCourseRequest").then((interception) => {
      console.log("Intercepted createCourseRequest:", interception);
    });

    
  });

  it("should update a course", () => {
    // Visit the course instructor page
    cy.visit("http://localhost:3000/course/Instructor", { timeout: 10000 });

    // Wait for the request to complete
    cy.wait("@coursesRequest").its("response.statusCode").should("eq", 200);

    // Click the Edit button for Course 1
    cy.get("button").contains("Edit").first().click();

    // Fill in the update course form
    cy.get('input[name="name"]').clear().type("Updated Course 1");
    cy.get('input[name="description"]')
      .clear()
      .type("Updated description for course 1");
    cy.get('button[type="submit"]').contains("Update Course").click();

    // Wait for the update course request to complete
    cy.wait("@updateCourseRequest").then((interception) => {
      console.log("Intercepted updateCourseRequest:", interception);
    });

    // Assert the course is updated in the list
    cy.get("h3").should("contain.text", "Updated Course 1");
    cy.get("p").should("contain.text", "Updated description for course 1");
  });

  it("should delete a course", () => {
    // Visit the course instructor page
    cy.visit("http://localhost:3000/course/Instructor", { timeout: 10000 });

    // Wait for the request to complete
    cy.wait("@coursesRequest").its("response.statusCode").should("eq", 200);

    // Click the Delete button for Course 1
    cy.get("button").contains("Delete").first().click();

    // Wait for the delete course request to complete
    cy.wait("@deleteCourseRequest").then((interception) => {
      console.log("Intercepted deleteCourseRequest:", interception);
    });

    // Assert the course is removed from the list
    cy.get("h3").should("not.contain.text", "Course 1");
  });

  it("should navigate to profile page", () => {
    // Visit the course instructor page
    cy.visit("http://localhost:3000/course/Instructor", { timeout: 10000 });

    // Click the Go to Profile button
    cy.get("button").contains("Go to Profile").click();

    // Assert the URL is correct
    cy.url().should("include", "/profile");
  });

  it("should navigate to manage lessons page", () => {
    // Visit the course instructor page
    cy.visit("http://localhost:3000/course/Instructor", { timeout: 10000 });

    // Wait for the request to complete
    cy.wait("@coursesRequest").its("response.statusCode").should("eq", 200);

    // Click the Manage Lessons button for Course 1
    cy.get("button").contains("Manage Lessons").first().click();

    // Assert the URL is correct
    cy.url().should("include", "/lessons/1");
  });
});
