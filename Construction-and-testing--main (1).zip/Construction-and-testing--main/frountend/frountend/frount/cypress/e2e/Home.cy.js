/* eslint-disable no-undef */
describe("Home Page Tests", () => {
  it("should display welcome message and navigation links", () => {
    // Visit the home page
    cy.visit("http://localhost:3000");

    // Assert welcome message is displayed
    cy.get("h1").should(
      "contain.text",
      "Welcome to BrainBuddies E-Learning Platform"
    );
    cy.get("p").should(
      "contain.text",
      "Learn from the best instructors and improve your skills today."
    );

    // Assert navigation links are displayed
    cy.get("a").contains("Register").should("be.visible");
    cy.get("a").contains("Login").should("be.visible");
  });

  it("should navigate to the register page when Register link is clicked", () => {
    // Visit the home page
    cy.visit("http://localhost:3000");

    // Click the Register link
    cy.get("a").contains("Register").click();

    // Assert the URL is correct
    cy.url().should("include", "/register");
  });

  it("should navigate to the login page when Login link is clicked", () => {
    // Visit the home page
    cy.visit("http://localhost:3000");

    // Click the Login link
    cy.get("a").contains("Login").click();

    // Assert the URL is correct
    cy.url().should("include", "/login");
  });
});
