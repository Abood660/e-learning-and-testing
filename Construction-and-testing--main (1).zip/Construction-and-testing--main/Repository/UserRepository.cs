using MongoDB.Driver;
using MongoExample.Models;

using MongoDB.Bson;

public class UserRepository
{
    private readonly MongoDbContext _context;

    public UserRepository(MongoDbContext context)
    {
        _context = context;
    }

    public async Task<User> GetUserByEmailAsync(string email)
    {
        return await _context.Users.Find(user => user.Email == email).FirstOrDefaultAsync();
    }

    public async Task<User?> GetUserByIdAsync(string userId)
    {
        if (ObjectId.TryParse(userId, out ObjectId objectId))
        {
            return await _context.Users.Find(user => user.Id == objectId).FirstOrDefaultAsync();
        }
        return null; 
    }

    public async Task CreateUserAsync(User user)
    {
        await _context.Users.InsertOneAsync(user);
    }
}
