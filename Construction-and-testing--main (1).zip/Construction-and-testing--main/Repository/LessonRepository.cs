using MongoDB.Driver;
using System.Collections.Generic;
using System.Threading.Tasks;

public class LessonRepository
{
    private readonly MongoDbContext _context;

    public LessonRepository(MongoDbContext context)
    {
        _context = context;
    }

    public async Task CreateLessonAsync(Lesson lesson)
    {
        try
        {
            await _context.Lessons.InsertOneAsync(lesson);
        }
        catch (MongoWriteException ex)
        {
            throw new Exception($"Failed to create lesson: {ex.Message}");
        }
    }

    public async Task<IEnumerable<Lesson>> GetLessonsByCourseIdAsync(string courseId)
    {
        try
        {
            return await _context.Lessons.Find(lesson => lesson.CourseId == courseId).ToListAsync();
        }
        catch (MongoException ex)
        {
            throw new Exception($"Failed to retrieve lessons: {ex.Message}");
        }
    }

    public async Task<Lesson> GetLessonByIdAsync(string lessonId)
    {
        try
        {
            return await _context.Lessons.Find(lesson => lesson.Id == lessonId).FirstOrDefaultAsync();
        }
        catch (MongoException ex)
        {
            throw new Exception($"Failed to retrieve lesson: {ex.Message}");
        }
    }

    public async Task UpdateLessonAsync(string lessonId, Lesson lesson)
    {
        try
        {
            var filter = Builders<Lesson>.Filter.Eq(l => l.Id, lessonId);
            var update = Builders<Lesson>.Update
                .Set(l => l.Title, lesson.Title)
                .Set(l => l.Url, lesson.Url);

            await _context.Lessons.UpdateOneAsync(filter, update);
        }
        catch (MongoWriteException ex)
        {
            throw new Exception($"Failed to update lesson: {ex.Message}");
        }
    }

    public async Task DeleteLessonAsync(string lessonId)
    {
        try
        {
            await _context.Lessons.DeleteOneAsync(lesson => lesson.Id == lessonId);
        }
        catch (MongoWriteException ex)
        {
            throw new Exception($"Failed to delete lesson: {ex.Message}");
        }
    }
}
