using MongoDB.Driver;
using System.Collections.Generic;
using System.Threading.Tasks;

public class CourseRepository
{
    private readonly MongoDbContext _context;

    public CourseRepository(MongoDbContext context)
    {
        _context = context;
    }

    public async Task CreateCourseAsync(Course course)
    {
        try
        {
            await _context.Courses.InsertOneAsync(course);
        }
        catch (MongoWriteException ex)
        {
            throw new Exception($"Failed to create course: {ex.Message}");
        }
    }

    public async Task<IEnumerable<Course>> GetAllCoursesAsync()
    {
        try
        {
            return await _context.Courses.Find(course => true).ToListAsync();
        }
        catch (MongoException ex)
        {
            throw new Exception($"Failed to retrieve courses: {ex.Message}");
        }
    }

    public async Task<Course> GetCourseByIdAsync(string courseId)
    {
        try
        {
            return await _context.Courses.Find(course => course.Id == courseId).FirstOrDefaultAsync();
        }
        catch (MongoException ex)
        {
            throw new Exception($"Failed to retrieve course by id: {ex.Message}");
        }
    }

    public async Task<Course> GetCourseByNameAsync(string name)
    {
        try
        {
            return await _context.Courses.Find(course => course.Name == name).FirstOrDefaultAsync();
        }
        catch (MongoException ex)
        {
            throw new Exception($"Failed to retrieve course by name: {ex.Message}");
        }
    }

    public async Task UpdateCourseAsync(string courseId, Course course)
    {
        try
        {
            var filter = Builders<Course>.Filter.Eq(c => c.Id, courseId);
            var update = Builders<Course>.Update
                .Set(c => c.Name, course.Name)
                .Set(c => c.Description, course.Description);

            await _context.Courses.UpdateOneAsync(filter, update);
        }
        catch (MongoWriteException ex)
        {
            throw new Exception($"Failed to update course: {ex.Message}");
        }
    }

    public async Task DeleteCourseAsync(string courseId)
    {
        try
        {
            await _context.Courses.DeleteOneAsync(course => course.Id == courseId);
        }
        catch (MongoWriteException ex)
        {
            throw new Exception($"Failed to delete course: {ex.Message}");
        }
    }

    public async Task<bool> IsStudentSubscribedToCourseAsync(string studentId, string courseId)
    {
        var filter = Builders<CourseSubscription>.Filter.And(
            Builders<CourseSubscription>.Filter.Eq(cs => cs.StudentId, studentId),
            Builders<CourseSubscription>.Filter.Eq(cs => cs.CourseId, courseId)
        );

        return await _context.CourseSubscriptions.Find(filter).AnyAsync();
    }    public async Task SubscribeStudentToCourseAsync(string studentId, string courseId)
    {
        if (await IsStudentSubscribedToCourseAsync(studentId, courseId))
        {
            throw new Exception("Student is already subscribed to this course.");
        }

        var subscription = new CourseSubscription
        {
            StudentId = studentId,
            CourseId = courseId,
            DateSubscribed = DateTime.UtcNow
        };
        await _context.CourseSubscriptions.InsertOneAsync(subscription);
    }

public async Task<int> GetSubscriptionCountForCourseAsync(string courseId)
{
    try
    {
        Console.WriteLine($"Counting subscriptions for course: {courseId}");
        var count = await _context.CourseSubscriptions.CountDocumentsAsync(cs => cs.CourseId == courseId);
        Console.WriteLine($"Found {count} subscriptions for course: {courseId}");
        return (int)count;
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error counting subscriptions: {ex.Message}");
        throw new Exception($"Failed to count subscriptions for course: {ex.Message}");
    }
}

}
