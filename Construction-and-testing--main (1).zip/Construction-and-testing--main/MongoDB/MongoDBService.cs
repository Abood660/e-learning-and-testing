using MongoDB.Driver;
using MongoExample.Models;

public class MongoDBService : IMongoDBService
{
    private readonly IMongoCollection<User> _collection;

    public MongoDBService(MongoDbContext context)
    {
        _collection = context.Users;
    }

    public async Task<IEnumerable<User>> GetAllAsync()
    {
        return await _collection.Find(_ => true).ToListAsync();
    }


    public async Task CreateAsync(User user)
    {
        await _collection.InsertOneAsync(user);
    }

    public async Task UpdateAsync(string id, User user)
    {
        await _collection.ReplaceOneAsync(m => m.Id == user.Id, user);
    }

    public Task<User> GetByIdAsync(string id)
    {
        throw new NotImplementedException();
    }

    public Task DeleteAsync(string id)
    {
        throw new NotImplementedException();
    }


}
