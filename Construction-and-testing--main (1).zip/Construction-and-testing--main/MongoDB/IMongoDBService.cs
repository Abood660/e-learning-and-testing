using MongoExample.Models;

public interface IMongoDBService
{
    Task<IEnumerable<User>> GetAllAsync();
    Task<User> GetByIdAsync(string id);
    Task CreateAsync(User user);
    Task UpdateAsync(string id, User model);
    Task DeleteAsync(string id);
}
