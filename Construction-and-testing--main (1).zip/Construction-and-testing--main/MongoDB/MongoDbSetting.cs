public class MongoDbSetting
{
    public required string ConnectionUri { get; set; }
}
