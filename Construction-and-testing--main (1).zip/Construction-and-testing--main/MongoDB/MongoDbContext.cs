using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoExample.Models;

public class MongoDbContext
{
    private readonly IMongoDatabase _database;

    public MongoDbContext(IOptions<MongoDbSetting> settings)
    {
        Console.WriteLine("MongoDbContext constructor called.");

        var clientSettings = MongoClientSettings.FromConnectionString(settings.Value.ConnectionUri);
        clientSettings.ServerApi = new ServerApi(ServerApiVersion.V1);

        var client = new MongoClient(clientSettings);

        _database = client.GetDatabase("BrainBuddiesDB");
    }

    public IMongoCollection<User> Users => _database.GetCollection<User>("user");

    public IMongoCollection<Course> Courses => _database.GetCollection<Course>("course");

    public IMongoCollection<Lesson> Lessons => _database.GetCollection<Lesson>("Lessons");

    public IMongoCollection<CourseSubscription> CourseSubscriptions => _database.GetCollection<CourseSubscription>("courseSubscriptions");
}
