using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Bson.Serialization.Serializers;
using MongoExample.Models;

public static class MongoDbClassMapping
{
    public static void RegisterClassMaps()
    {
        var conventionPack = new ConventionPack { new CamelCaseElementNameConvention() };
        ConventionRegistry.Register("CamelCase", conventionPack, t => true);

        BsonClassMap.RegisterClassMap<User>(cm =>
        {
            cm.AutoMap();
            cm.SetIsRootClass(true);
            cm.AddKnownType(typeof(Student));
            cm.AddKnownType(typeof(Instructor));
        });

        BsonClassMap.RegisterClassMap<Student>(cm =>
        {
            cm.AutoMap();
            cm.SetDiscriminator("Student");
        });

        BsonClassMap.RegisterClassMap<Instructor>(cm =>
        {
            cm.AutoMap();
            cm.SetDiscriminator("Instructor");
        });
        
    }
}
